#include <iostream>
using namespace std;
int main()
{
    string cars[4] = {"volvo","BMW","Tesla","Ford"};
    cars[0] = "opel";
    cout << cars[0];
    
    return 0;
}
